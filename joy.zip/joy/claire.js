function validdetails(email,password){
    const validEmail = "Nasali mary clair@gmail.com";
    const validPassword = "2200704690@2024";

    if (email === validEmail && password === validPassword){
        console.log('user email is ${email}, login successfully!' );
    } else{
        console.log('inncorrect user credentials');
    }
}
validdetails('Nasali mary clair@gmail','2200704690@2024');